<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use App\Models\Rules;
use Illuminate\Http\Request;

class RulesAdminController extends Controller
{
    public function index()
    {
        $rules = Rules::all();
        return view('admin.rulesadmin.rules_admin', compact('rules'));
    }

    public function store(Request $request)
    {
        Rules::create([
            'rules_headline' => $request->rules_headline,
            'rules_description' => $request->rules_description,
            'is_published' => $request->input('is_published', 1),
        ]);

        return redirect('/admin/dashboard/rules_admin')->with('success', 'Rules added successfully');
    }

    public function update(Request $request, $rules_id)
    {
        $rule = Rules::findOrFail($rules_id);
        $rule->update([
            'rules_headline' => $request->rules_headline,
            'rules_description' => $request->rules_description,
            'is_published' => $request->is_published, 
        ]);

        return redirect('admin/dashboard/rules_admin')->with('success', 'Rules updated successfully');
    }

    public function destroy($id)
    {
        Rules::where('rules_id', $id)->delete();
        return back()->with('success', 'Rules deleted successfully');
    }
}